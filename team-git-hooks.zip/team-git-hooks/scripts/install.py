#!/usr/bin/env python3
"""
Git Hooks 一键安装脚本
将 skill 中的 hook 脚本安装到当前项目，并配置各项功能。

用法:
    python3 install.py                    # 交互式安装
    python3 install.py --all              # 启用所有功能
    python3 install.py --size 800         # 提交量检查，阈值 800
    python3 install.py --test             # 单元测试
    python3 install.py --msg               # 提交信息格式检查
    python3 install.py --merge main        # 自动合并分支
    python3 install.py --uninstall        # 卸载所有 hooks
    python3 install.py --show             # 查看当前项目配置
"""

import os
import sys
import stat
import shutil
import subprocess
from pathlib import Path


SKILL_DIR = Path(__file__).parent.resolve()


def run(cmd: list[str], **kwargs):
    return subprocess.run(cmd, **kwargs)


def is_interactive():
    return sys.stdin.isatty()


def ask(prompt: str, default: str = "") -> str:
    if is_interactive():
        try:
            val = input(prompt).strip()
            return val if val else default
        except (EOFError, KeyboardInterrupt):
            pass
    return default


def is_git_repo() -> bool:
    result = run(["git", "rev-parse", "--is-inside-work-tree"], capture_output=True, text=True)
    return result.returncode == 0 and result.stdout.strip() == "true"


def get_repo_root() -> str:
    result = run(["git", "rev-parse", "--show-toplevel"], capture_output=True, text=True)
    if result.returncode == 0:
        return result.stdout.strip()
    return ""


def get_current_hooks_path() -> str:
    result = run(["git", "config", "core.hooksPath"], capture_output=True, text=True)
    if result.returncode == 0 and result.stdout.strip():
        return result.stdout.strip()
    return ""


def install_hooks(repo_root: str):
    """将 hook 脚本安装到项目的 .githooks/ 目录"""
    project_hooks = Path(repo_root) / ".githooks"
    project_hooks.mkdir(parents=True, exist_ok=True)

    # 复制所有脚本
    for f in SKILL_DIR.glob("*.py"):
        shutil.copy2(f, project_hooks / f.name)
        os.chmod(project_hooks / f.name, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

    for f in SKILL_DIR.glob("pre-commit"):
        shutil.copy2(f, project_hooks / "pre-commit")
        os.chmod(project_hooks / "pre-commit", stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

    for f in SKILL_DIR.glob("post-commit"):
        shutil.copy2(f, project_hooks / "post-commit")
        os.chmod(project_hooks / "post-commit", stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

    for f in SKILL_DIR.glob("commit-msg"):
        shutil.copy2(f, project_hooks / "commit-msg")
        os.chmod(project_hooks / "commit-msg", stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP | stat.S_IROTH | stat.S_IXOTH)

    # 配置 core.hooksPath
    run(["git", "config", "core.hooksPath", str(project_hooks)], cwd=repo_root)
    print(f"✅ 已安装 hooks 到 .githooks/")


def uninstall_hooks(repo_root: str):
    """卸载 hooks"""
    project_hooks = Path(repo_root) / ".githooks"
    if project_hooks.exists():
        # 取消 core.hooksPath
        run(["git", "config", "--unset", "core.hooksPath"], cwd=repo_root)
        # 清空配置
        for key in ["commitSize.threshold", "autoTest.enabled", "autoMerge.branch", "commitMsg.check"]:
            run(["git", "config", "--unset", key], cwd=repo_root)
        print(f"✅ 已卸载 hooks，清除了 .githooks/ 配置")
    else:
        print(f"⚠️  未找到 .githooks/ 目录")


def configure(repo_root: str, enable_size: bool, threshold: str,
              enable_test: bool, enable_merge: bool, merge_branch: str,
              enable_msg: bool):
    """配置各项功能"""
    if enable_size:
        try:
            int(threshold)
        except ValueError:
            threshold = "1000"
        run(["git", "config", "--local", "commitSize.threshold", threshold], cwd=repo_root)
        print(f"✅ 提交量检查 [已启用，阈值 {threshold} 行]")
    else:
        run(["git", "config", "--local", "--unset", "commitSize.threshold"], cwd=repo_root)
        print(f"⏭️  提交量检查 [跳过]")

    if enable_test:
        run(["git", "config", "--local", "autoTest.enabled", "true"], cwd=repo_root)
        print(f"✅ 单元测试 [已启用]")
    else:
        run(["git", "config", "--local", "--unset", "autoTest.enabled"], cwd=repo_root)
        print(f"⏭️  单元测试 [跳过]")

    if enable_merge:
        run(["git", "config", "--local", "autoMerge.branch", merge_branch], cwd=repo_root)
        print(f"✅ 自动合并分支 [已启用，目标: {merge_branch}]")
    else:
        run(["git", "config", "--local", "--unset", "autoMerge.branch"], cwd=repo_root)
        print(f"⏭️  自动合并分支 [跳过]")

    if enable_msg:
        run(["git", "config", "--local", "commitMsg.check", "true"], cwd=repo_root)
        print(f"✅ 提交信息格式检查 [已启用]")
    else:
        run(["git", "config", "--local", "--unset", "commitMsg.check"], cwd=repo_root)
        print(f"⏭️  提交信息格式检查 [跳过]")


def show_status(repo_root: str):
    """显示当前项目配置"""
    configs = [
        ("commitSize.threshold", "提交量检查阈值"),
        ("autoTest.enabled", "单元测试"),
        ("autoMerge.branch", "自动合并分支"),
        ("commitMsg.check", "提交信息格式检查"),
    ]
    print(f"\n📋 当前项目 hook 配置：")
    print(f"   hooks 目录: {get_current_hooks_path() or '未配置'}")
    for key, label in configs:
        val = run(["git", "config", "--local", "--get", key], cwd=repo_root, capture_output=True, text=True)
        if val.returncode == 0 and val.stdout.strip():
            print(f"   ✅ {label}: {val.stdout.strip()}")
        else:
            print(f"   ⬜ {label}: 未启用")


def interactive_install(repo_root: str):
    """交互式安装"""
    print("=" * 50)
    print("  Git Hooks 一键安装")
    print("=" * 50)
    print(f"\n项目: {repo_root}")
    print()

    threshold = ask("  📏 提交量检查阈值（行，默认 1000）: ", "1000")
    enable_test = ask("  🧪 是否启用单元测试? (y/N): ", "n").lower() == "y"
    enable_merge = ask("  🔄 是否启用自动合并分支? (y/N): ", "n").lower() == "y"
    merge_branch = "main"
    if enable_merge:
        merge_branch = ask("     合并到哪个分支（默认 main）: ", "main")
    enable_msg = ask("  📝 是否启用提交信息格式检查? (y/N): ", "n").lower() == "y"

    try:
        int(threshold)
    except ValueError:
        threshold = "1000"

    return threshold, enable_test, enable_merge, merge_branch, enable_msg


def main():
    if not is_git_repo():
        print("❌ 当前目录不是 Git 仓库")
        sys.exit(1)

    repo_root = get_repo_root()
    args = sys.argv[1:]

    if "--show" in args or "-l" in args:
        show_status(repo_root)
        return

    if "--uninstall" in args:
        uninstall_hooks(repo_root)
        return

    # 解析参数
    enable_test = "--test" in args
    enable_merge = "--merge" in args
    enable_msg = "--msg" in args
    enable_size = "--size" in args or "--all" in args
    threshold = "1000"
    merge_branch = "main"

    for i, arg in enumerate(args):
        if arg == "--size" and i + 1 < len(args):
            threshold = args[i + 1]
        if arg == "--merge" and i + 1 < len(args):
            merge_branch = args[i + 1]

    # 安装 hooks
    install_hooks(repo_root)

    # 配置
    if not args or "--all" in args:
        threshold, enable_test, enable_merge, merge_branch, enable_msg = interactive_install(repo_root)

    configure(repo_root, enable_size, threshold, enable_test, enable_merge, merge_branch, enable_msg)

    show_status(repo_root)

    print(f"""
💡 常用命令：
  python3 .githooks/setup-hooks.py --show      # 查看配置
  python3 .githooks/setup-hooks.py --disable  # 禁用所有
  git config --local commitSize.threshold 800  # 修改阈值
""")


if __name__ == "__main__":
    main()
