---
name: team-git-hooks
description: |
  团队共用 Git Hooks 工具箱。提供预置的提交前/后检查脚本，支持提交量检查、单元测试、
  提交信息格式校验、自动合并分支。适用于希望建立统一 Git 工作流的团队，
  可一键安装到任意项目，所有脚本纳入版本控制，团队成员共享。
---

## 用途

为项目批量安装一套开箱即用的 Git Hooks，帮助团队统一代码质量标准。
所有脚本放在项目 `.githooks/` 目录下，通过 `core.hooksPath` 指向该目录，
纳入版本控制，团队成员 clone 后一键配置即可使用。

## 触发条件

当用户提到以下意图时使用此 skill：
- "帮我安装 git hooks" / "安装团队 hooks"
- "配置提交检查" / "设置 pre-commit hook"
- "团队共用 hooks" / "team git hooks"
- "提交规范检查" / "commit 检查"

## 支持的功能

| Hook | 阶段 | 功能描述 |
|------|------|----------|
| `pre-commit` | 提交前 | 提交量检查 + 单元测试 |
| `commit-msg` | 提交信息 | 格式校验（story/bugfix 开头） |
| `post-commit` | 提交后 | 自动合并指定分支到当前分支 |

## 工作流程

### 第一步：安装 Hooks 到项目

当用户请求安装 hooks 时，运行安装脚本：

```bash
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py
```

该脚本会自动：
1. 将所有 hook 脚本复制到当前项目的 `.githooks/` 目录
2. 配置 `git config core.hooksPath` 指向 `.githooks/`
3. 根据用户选择启用各项功能

### 第二步：配置功能

交互式配置：
```bash
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py
```

命令行配置：
```bash
# 启用所有功能（默认阈值 1000 行）
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py --all

# 自定义配置
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py --size 800   # 提交量检查，阈值 800 行
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py --test      # 启用单元测试
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py --msg        # 启用提交信息格式检查
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py --merge main # 自动合并 main 分支
```

### 第三步：管理功能开关

```bash
# 查看当前配置
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py --show

# 禁用所有 hooks
python3 ~/.codebuddy/skills/team-git-hooks/scripts/install.py --uninstall

# git config 管理
git config --local commitSize.threshold 1000         # 设置阈值
git config --local autoTest.enabled true             # 启用测试
git config --local autoMerge.branch main             # 自动合并分支
git config --local commitMsg.check true             # 提交信息格式检查
```

## 核心脚本说明

### `install.py` — 一键安装（入口脚本）

- 检测当前项目是否为 Git 仓库
- 复制所有 hook 脚本到项目的 `.githooks/` 目录
- 配置 `core.hooksPath`
- 支持交互式和命令行两种模式

### `check_commit_size.py` — 提交量检查

- 检查本次提交改动量是否超过阈值（默认 1000 行）
- 超过则拦截并给出分批提交建议
- 支持通过 `commitSize.threshold` 配置阈值

### `run_unit_tests.py` — 单元测试

- 自动检测项目类型（Maven/Gradle/npm/Cargo/go/pytest）
- 测试不通过则阻止提交
- 支持自定义测试命令

### `check_commit_msg.py` — 提交信息格式检查

- 必须以 `story:` 或 `bugfix:` 开头
- 支持大小写不敏感匹配
- 示例：
  - `story: 添加用户登录功能`（允许）
  - `bugfix: 修复登录闪退`（允许）
  - `feat: 新功能`（不允许）

### `auto_merge_branch.py` — 自动合并分支

- 每次提交后自动将指定分支合并到当前分支
- 合并后自动推送到远程
- 支持多分支配置

## 文件结构

```
.githooks/                     # 纳入版本控制
├── pre-commit                 # 提交前检查入口（shell 脚本）
├── post-commit                # 提交后自动合并（shell 脚本）
├── commit-msg                 # 提交信息检查（shell 脚本）
├── install.py                 # 一键安装脚本（仅 skill 中有）
├── check_commit_size.py      # 提交量检查
├── run_unit_tests.py         # 单元测试
├── check_commit_msg.py       # 提交信息格式检查
└── auto_merge_branch.py      # 自动合并分支
```

## 依赖

- Python 3.6+
- Git
- 项目对应的构建工具（Maven/Gradle/npm 等，取决于使用的功能）

## 注意事项

- `core.hooksPath` 配置在 `.git/config` 中，不会提交到仓库
- 脚本本身通过 `install.py` 部署到 `.githooks/` 目录后纳入版本控制
- hook 脚本路径在脚本内部通过 `git rev-parse --show-toplevel` 动态获取，无需硬编码
- 提交量检查默认读取 `commitSize.threshold`，未配置则不检查
- 单元测试默认读取 `autoTest.enabled`，未启用则不检查
