---
name: commit-size-checker
description: |
  Git 提交代码量检查工具。当用户提交代码时自动检查本次提交改动量是否超过阈值（默认 1000 行），
  超过则拦截提交并提供分批提交建议。此 skill 包含核心检查脚本和 hook 安装脚本，
  适用于 Java/TypeScript/任意语言的 Git 项目。
---

## 用途

在每次 `git commit` 时自动检查改动量，超过阈值则阻止提交并给出分批提交方案，
帮助保持提交粒度合理、便于代码审查。

## 触发条件

当用户提到以下意图时使用此 skill：
- "帮我安装提交检查" / "安装 commit hook"
- "检查一下本次提交改动量"
- "提交被拦截了" / "commit 太大了"
- "帮我分批提交"
- "提交代码时检查改动量"

## 工作流程

### 第一步：安装 Hook

运行安装脚本，为项目安装 Git hook：

```bash
python3 ~/.codebuddy/skills/commit-size-checker/scripts/install_hooks.py
```

参数：
- `--threshold <N>` 或 `-t <N>`：设置行数阈值（默认 1000）
- `--global` 或 `-g`：全局安装（所有仓库生效）
- `--repo <path>`：为指定仓库安装

示例：
```bash
# 当前仓库安装，阈值 500 行
python3 ~/.codebuddy/skills/commit-size-checker/scripts/install_hooks.py -t 500

# 全局安装（所有仓库生效）
python3 ~/.codebuddy/skills/commit-size-checker/scripts/install_hooks.py --global

# 指定仓库安装
python3 ~/.codebuddy/skills/commit-size-checker/scripts/install_hooks.py --repo /path/to/project
```

### 第二步：使用 Hook

Hook 安装后，每次 `git commit` 时自动触发检查：

1. 用户执行 `git add` 暂存文件
2. 用户执行 `git commit -m "message"`
3. hook 自动运行 `check_commit_size.py` 分析改动量
4. 如果改动量 ≤ 阈值：提交成功
5. 如果改动量 > 阈值：提交被拦截，脚本输出统计和分批建议

### 第三步：按建议分批提交

根据脚本给出的分批建议，用户逐批提交：

```bash
# 例如建议分 3 批
git add src/module1/ src/module2/
git commit -m "feat: 模块1和模块2的重构"

git add src/module3/
git commit -m "feat: 模块3的新功能"

git add src/module4/
git commit -m "feat: 模块4的修复"
```

### 手动运行检查（无需 hook）

在未安装 hook 的情况下，用户也可以手动运行检查：

```bash
python3 ~/.codebuddy/skills/commit-size-checker/scripts/check_commit_size.py
```

环境变量覆盖阈值：`COMMIT_SIZE_THRESHOLD=500 python3 .../check_commit_size.py`

## 核心脚本说明

### `scripts/check_commit_size.py`

分析 git diff 输出，计算改动行数并生成分批建议：

- 解析 `git diff --numstat --cached` 获取暂存区改动
- 按包/目录对文件分组，便于理解模块边界
- 根据阈值智能生成分批方案（优先将大文件独立出来）
- 输出格式：终端人类可读 + `__JSON_RESULT__:...` 供程序解析

### `scripts/install_hooks.py`

安装 Git hook，支持仓库级别和全局级别：

- 自动检测当前仓库路径
- 保留已有 hook 内容，追加而非覆盖
- 设置正确的文件权限
- 全局安装通过 `git config core.hooksPath` 实现

## 依赖

- Python 3.6+
- Git（已安装并配置）

## 注意事项

- hook 使用 `commit-msg` 阶段（检查提交信息时），检查的是**已暂存**的文件改动
- 仅统计新增行 + 删除行，不统计未追踪的新文件（如需统计，可修改脚本）
- 二进制文件显示为 `-` 而不是行数，脚本会跳过
- 对于 monorepo 项目，分组逻辑会自动按子目录聚合
